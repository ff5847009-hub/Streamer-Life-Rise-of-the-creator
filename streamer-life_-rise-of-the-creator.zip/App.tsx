
import React, { useState, useEffect } from 'react';
import { DeviceType, GameState, PlayerStats, Item, Message, StreamSession, ChatMessage, VideoEntry, Transaction, GameItem } from './types';
import { INITIAL_STATS, MARKET_ITEMS, GAME_STORE_ITEMS } from './constants';
import MainMenu from './components/MainMenu';
import DeviceSelector from './components/DeviceSelector';
import PCMode from './components/PC/PCMode';
import HPMode from './components/Mobile/HPMode';
import Credits from './components/Credits';

const SAVE_KEY = 'streamer_life_save_v1';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'MENU' | 'SELECTOR' | 'GAME' | 'CREDITS'>('MENU');
  const [device, setDevice] = useState<DeviceType>(DeviceType.NONE);
  const [gameState, setGameState] = useState<GameState>(() => {
    const saved = localStorage.getItem(SAVE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to load save", e);
      }
    }
    return {
      stats: INITIAL_STATS,
      inventory: [],
      ownedGames: ['game_0', 'game_1'],
      uploadedVideos: [],
      transactions: [],
      messages: [
        { id: '1', sender: 'OneComplier', content: 'Selamat datang Ryu! Gunakan aplikasi Wallet untuk mengatur DECON dan SALDO Anda.', timestamp: '08:00 AM', isRead: false },
        { id: '2', sender: 'Sponsor', content: 'Kami sedang mencari streamer baru untuk mempromosikan produk indie realm. Tertarik?', timestamp: '09:15 AM', isRead: false },
      ],
      activeApp: null,
      isStreaming: false,
      streamData: null,
    };
  });

  // Auto-save whenever gameState changes
  useEffect(() => {
    localStorage.setItem(SAVE_KEY, JSON.stringify(gameState));
  }, [gameState]);

  const resetData = () => {
    if (confirm("Apakah Anda yakin ingin menghapus semua data permainan?")) {
      localStorage.removeItem(SAVE_KEY);
      window.location.reload();
    }
  };

  const addTransaction = (type: Transaction['type'], amount: number, description: string) => {
    setGameState(prev => ({
      ...prev,
      transactions: [{
        type, amount, description,
        timestamp: new Date().toLocaleTimeString()
      }, ...prev.transactions].slice(0, 50)
    }));
  };

  const handleStopStream = () => {
    setGameState(prev => {
      if (!prev.streamData) return prev;
      let adsense = 0;
      if (prev.stats.subscribers >= 200 && prev.streamData.viewers >= 20) {
        adsense = Math.floor(prev.streamData.viewers * 12);
      }
      
      const summary: VideoEntry = {
        id: Date.now().toString(),
        title: `VOD: ${prev.streamData.gameId} Live`,
        views: 0,
        targetViews: prev.streamData.viewers * 8,
        likes: prev.streamData.likes,
        subsGained: Math.floor(prev.streamData.viewers * 0.08),
        adsenseEarned: adsense,
        uploadDate: new Date().toISOString(),
        gameId: prev.streamData.gameId,
        status: 'uploaded',
        editProgress: 100
      };

      if (adsense > 0) addTransaction('income', adsense, 'Stream Adsense');

      return {
        ...prev,
        isStreaming: false,
        streamData: null,
        uploadedVideos: [summary, ...prev.uploadedVideos],
        stats: {
          ...prev.stats,
          decon: prev.stats.decon + adsense,
          energy: Math.max(0, prev.stats.energy - 10),
          day: prev.stats.day + 1
        }
      };
    });
  };

  // Video view growth and Adsense calculation
  useEffect(() => {
    const growthInterval = setInterval(() => {
      setGameState(prev => {
        let adsenseTotal = 0;
        const updatedVideos = prev.uploadedVideos.map(video => {
          if (video.status === 'uploaded' && video.views < video.targetViews) {
            const growth = Math.max(1, Math.floor((video.targetViews - video.views) * 0.05));
            const newViews = video.views + growth;
            
            let newAdsense = 0;
            if (newViews >= 500 && video.views < 500) {
              newAdsense = 250;
            } else if (newViews >= 500) {
              newAdsense = Math.floor(growth * 0.2);
            }
            adsenseTotal += newAdsense;
            
            return { ...video, views: newViews, adsenseEarned: video.adsenseEarned + newAdsense };
          }
          return video;
        });

        if (adsenseTotal > 0 || updatedVideos !== prev.uploadedVideos) {
          const newState = { ...prev, uploadedVideos: updatedVideos };
          if (adsenseTotal > 0) {
            newState.stats = { ...newState.stats, decon: newState.stats.decon + adsenseTotal };
          }
          return newState;
        }
        return prev;
      });
    }, 4000);

    return () => clearInterval(growthInterval);
  }, []);

  // Energy and Hunger decay
  useEffect(() => {
    const decayInterval = setInterval(() => {
      setGameState(prev => {
        if (!prev.isStreaming && prev.stats.energy <= 0 && prev.stats.hunger <= 0) return prev;
        
        const energyLoss = prev.isStreaming ? 2.5 : 0.2;
        const hungerLoss = prev.isStreaming ? 1.5 : 0.3;

        const newEnergy = Math.max(0, prev.stats.energy - energyLoss);
        const newHunger = Math.max(0, prev.stats.hunger - hungerLoss);

        if (prev.isStreaming && newEnergy <= 0) {
          setTimeout(() => handleStopStream(), 0);
        }

        return {
          ...prev,
          stats: {
            ...prev.stats,
            energy: newEnergy,
            hunger: newHunger,
            mentalHealth: newHunger < 10 ? Math.max(0, prev.stats.mentalHealth - 1) : prev.stats.mentalHealth
          }
        };
      });
    }, 5000);

    return () => clearInterval(decayInterval);
  }, []);

  // Stream simulation loop
  useEffect(() => {
    let interval: any;
    if (gameState.isStreaming) {
      interval = setInterval(() => {
        setGameState(prev => {
          if (!prev.isStreaming || !prev.streamData) return prev;
          
          const subFactor = Math.floor(prev.stats.subscribers / 100);
          const baseGrowth = 1 + subFactor;
          const streamQuality = 1 + (prev.inventory.length * 0.15);
          const viewersDelta = Math.floor(Math.random() * (4 + baseGrowth) * streamQuality);
          
          const chatTemplates = [
            "Pog!", "LUL", "Ryu logic haha", "Nice gameplay", "Wait, what just happened?",
            "Clutch!!", "Lag?", "No lag for me", "OneComplier quality", "Indie Realm hype!",
            "Eat something bro", "Energy check?", "Keep it up!", "Love from fans", "PogChamp"
          ];
          
          const newChat: ChatMessage = {
            id: Date.now().toString() + Math.random(),
            user: `User_${Math.floor(Math.random()*999)}`,
            text: chatTemplates[Math.floor(Math.random() * chatTemplates.length)],
            type: 'positive'
          };

          let donationAmount = 0;
          if (Math.random() > 0.93) {
             const possibleAmounts = [5000, 10000, 25000, 50000];
             donationAmount = possibleAmounts[Math.floor(Math.random() * possibleAmounts.length)];
             newChat.text = `Donated ${donationAmount.toLocaleString()} DECON! Semangat Ryu!`;
             newChat.type = 'donation';
             newChat.amount = donationAmount;
          }

          return {
            ...prev,
            stats: {
              ...prev.stats,
              decon: prev.stats.decon + donationAmount,
              experience: prev.stats.experience + 3,
              subscribers: prev.stats.subscribers + (Math.random() > 0.85 ? 1 : 0)
            },
            streamData: {
              ...prev.streamData,
              viewers: Math.max(1, prev.streamData.viewers + (Math.random() > 0.3 ? viewersDelta : -Math.floor(viewersDelta * 0.4))),
              likes: prev.streamData.likes + (Math.random() > 0.8 ? 1 : 0),
              duration: prev.streamData.duration + 1,
              totalDonation: prev.streamData.totalDonation + donationAmount,
              chat: [...prev.streamData.chat, newChat].slice(-20)
            }
          };
        });
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [gameState.isStreaming]);

  const enterFullScreen = () => {
    const doc = window.document.documentElement;
    if (doc.requestFullscreen) {
      doc.requestFullscreen().catch(() => {});
    }
  };

  const handleBuyGame = (game: GameItem) => {
    if (gameState.stats.decon >= game.price) {
      setGameState(prev => ({
        ...prev,
        stats: { ...prev.stats, decon: prev.stats.decon - game.price },
        ownedGames: [...prev.ownedGames, game.id]
      }));
      addTransaction('expense', game.price, `Beli Game: ${game.name}`);
      return true;
    }
    return false;
  };

  const handleWithdrawSaldo = (amountSaldo: number) => {
    if (gameState.stats.saldo >= amountSaldo) {
      setGameState(prev => ({
        ...prev,
        stats: {
          ...prev.stats,
          saldo: prev.stats.saldo - amountSaldo,
          decon: prev.stats.decon + amountSaldo
        }
      }));
      addTransaction('income', amountSaldo, `Tarik Saldo ke Decon`);
      return true;
    }
    return false;
  };

  return (
    <div className="w-full h-screen bg-slate-950 text-white overflow-hidden select-none">
      {currentView === 'MENU' && <MainMenu 
        onPlay={() => { enterFullScreen(); setCurrentView('SELECTOR'); }} 
        onCredits={() => setCurrentView('CREDITS')} 
        onReset={resetData}
        onExit={() => {}} 
      />}
      {currentView === 'SELECTOR' && <DeviceSelector onSelect={(d) => { setDevice(d); setCurrentView('GAME'); }} onBack={() => setCurrentView('MENU')} />}
      {currentView === 'CREDITS' && <Credits onBack={() => setCurrentView('MENU')} />}
      {currentView === 'GAME' && (
        device === DeviceType.PC ? (
          <PCMode 
            gameState={gameState} 
            setGameState={setGameState} 
            onBuyItem={(item) => {
               if (gameState.stats.decon >= item.price) {
                 setGameState(prev => ({ ...prev, stats: { ...prev.stats, decon: prev.stats.decon - item.price }, inventory: [...prev.inventory, item.id] }));
                 addTransaction('expense', item.price, `Upgrade: ${item.name}`);
                 return true;
               }
               return false;
            }}
            onStartStream={(conf) => setGameState(prev => ({ ...prev, isStreaming: true, streamData: { ...conf, viewers: 5, likes: 0, dislikes: 0, duration: 0, chat: [], totalDonation: 0 } }))}
            onStopStream={handleStopStream}
            onMainMenu={() => setCurrentView('MENU')}
            onBuyGame={handleBuyGame}
            onWithdrawSaldo={handleWithdrawSaldo}
          />
        ) : (
          <HPMode 
            gameState={gameState} 
            setGameState={setGameState}
            onBuyItem={(item) => {
               if (gameState.stats.decon >= item.price) {
                 setGameState(prev => ({ ...prev, stats: { ...prev.stats, decon: prev.stats.decon - item.price }, inventory: [...prev.inventory, item.id] }));
                 return true;
               }
               return false;
            }}
            onMainMenu={() => setCurrentView('MENU')}
          />
        )
      )}
      <div className="fixed bottom-2 right-4 text-[10px] text-slate-500 opacity-50 z-[999]">
        OneComplier Auto-Saving...
      </div>
    </div>
  );
};

export default App;
