
import { Item, PlayerStats, GameItem } from './types';

export const INITIAL_STATS: PlayerStats = {
  decon: 1000,
  saldo: 0,
  subscribers: 0,
  experience: 0,
  mentalHealth: 100,
  energy: 100,
  hunger: 100,
  day: 1,
  ranking: 9999,
};

export const MARKET_ITEMS: Item[] = [
  { id: 'webcam_1', name: 'Basic 720p Webcam', category: 'Camera', price: 15000, qualityBonus: 5 },
  { id: 'webcam_2', name: 'Pro 4K Cam', category: 'Camera', price: 120000, qualityBonus: 25 },
  { id: 'mic_1', name: 'Usb Mic Start', category: 'Microphone', price: 8000, qualityBonus: 8 },
  { id: 'mic_2', name: 'XLR Studio Mic', category: 'Microphone', price: 60000, qualityBonus: 30 },
  { id: 'light_1', name: 'Small Ring Light', category: 'Lighting', price: 4500, qualityBonus: 10 },
  { id: 'pc_1', name: 'Budget Gamer Rig', category: 'PC', price: 80000, qualityBonus: 15 },
  { id: 'pc_2', name: 'Monster Workstation', category: 'PC', price: 350000, qualityBonus: 60 },
  { id: 'mon_1', name: '60Hz Monitor', category: 'Monitor', price: 12000, qualityBonus: 5 },
  { id: 'chair_1', name: 'Ergo Office Chair', category: 'Furniture', price: 25000, qualityBonus: 12 },
];

export const GAME_STORE_ITEMS: GameItem[] = [
  { id: 'game_0', name: 'Just Chatting', price: 0, quality: 1, isFree: true },
  { id: 'game_1', name: 'League of Titans', price: 0, quality: 2, isFree: true },
  { id: 'game_2', name: 'CraftMine', price: 15000, quality: 2, isFree: false },
  { id: 'game_3', name: 'Valor Strike', price: 45000, quality: 3, isFree: false },
  { id: 'game_4', name: 'Cyber Rogue', price: 85000, quality: 3, isFree: false },
];

export const FOOD_ITEMS = [
  { id: 'food_1', name: 'Mie Instan', price: 50, hunger: 20, energy: 5 },
  { id: 'food_2', name: 'Nasi Goreng', price: 200, hunger: 45, energy: 15 },
  { id: 'food_3', name: 'Steak Premium', price: 1200, hunger: 80, energy: 40 },
  { id: 'food_4', name: 'Kopi Kapal Api', price: 100, hunger: 5, energy: 30 },
];
