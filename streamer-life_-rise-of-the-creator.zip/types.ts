
export enum DeviceType {
  HP = 'HP',
  PC = 'PC',
  NONE = 'NONE'
}

export interface Item {
  id: string;
  name: string;
  category: 'Camera' | 'Microphone' | 'Lighting' | 'Monitor' | 'PC' | 'Furniture';
  price: number;
  qualityBonus: number;
}

export interface GameItem {
  id: string;
  name: string;
  price: number;
  quality: number; // 1: Low, 2: Mid, 3: High
  isFree: boolean;
}

export interface VideoEntry {
  id: string;
  title: string;
  views: number;
  targetViews: number;
  likes: number;
  subsGained: number;
  adsenseEarned: number;
  uploadDate: string;
  gameId: string;
  status: 'raw' | 'editing' | 'ready' | 'uploaded';
  editProgress: number;
}

export interface PlayerStats {
  decon: number; 
  saldo: number; 
  subscribers: number;
  experience: number;
  mentalHealth: number;
  energy: number;
  hunger: number; // Added hunger system
  day: number;
  ranking: number;
}

export interface Transaction {
  type: 'income' | 'expense' | 'withdrawal' | 'topup';
  amount: number;
  description: string;
  timestamp: string;
}

export interface GameState {
  stats: PlayerStats;
  inventory: string[]; 
  ownedGames: string[]; 
  uploadedVideos: VideoEntry[];
  transactions: Transaction[];
  messages: Message[];
  activeApp: string | null;
  isStreaming: boolean;
  streamData: StreamSession | null;
}

export interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface StreamSession {
  gameId: string;
  viewers: number;
  likes: number;
  dislikes: number;
  duration: number; 
  chat: ChatMessage[];
  totalDonation: number;
}

export interface ChatMessage {
  id: string;
  user: string;
  text: string;
  type: 'positive' | 'negative' | 'donation';
  amount?: number;
}

export interface AppWindow {
  name: string;
  minimized: boolean;
  maximized: boolean;
  zIndex: number;
  position: { x: number; y: number };
}
