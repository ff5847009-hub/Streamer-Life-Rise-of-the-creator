
import React from 'react';

interface CreditsProps {
  onBack: () => void;
}

const Credits: React.FC<CreditsProps> = ({ onBack }) => {
  return (
    <div className="h-full bg-slate-950 overflow-y-auto p-8 text-center flex flex-col items-center">
      <h2 className="text-4xl font-black text-red-600 mb-12">CREDITS</h2>
      <div className="max-w-2xl w-full space-y-12 mb-20">
        <section>
          <h3 className="text-xl font-bold text-white mb-4 border-b border-slate-800 pb-2">Bloxy Studios</h3>
          <div className="grid grid-cols-2 gap-4 text-slate-400">
            <div><span className="text-red-400 font-bold">Ryu Delvino</span> - Project Lead</div>
            <div><span className="text-red-400 font-bold">Faiz</span> - UI/UX</div>
            <div><span className="text-red-400 font-bold">Ahmad</span> - Coding</div>
            <div><span className="text-red-400 font-bold">Jian</span> - Backend Logic</div>
          </div>
        </section>
        <div className="p-6 bg-slate-900 rounded-xl border border-slate-800">
           <p className="text-xs text-slate-500 mb-2 font-black tracking-widest uppercase">OneComplier</p>
           <p className="text-sm text-slate-400 leading-relaxed italic">
             “Produk ini dikembangkan sepenuhnya oleh tim developer manual dengan bantuan logic AI OneComplier untuk optimalisasi performa dan sistem simulasi.”
           </p>
        </div>
      </div>
      <button onClick={onBack} className="fixed bottom-8 bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-black shadow-lg transition-all">BACK</button>
    </div>
  );
};

export default Credits;
