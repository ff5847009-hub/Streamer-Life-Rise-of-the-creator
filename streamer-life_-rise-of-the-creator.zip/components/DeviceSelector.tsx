
import React from 'react';
import { DeviceType } from '../types';

interface DeviceSelectorProps {
  onSelect: (device: DeviceType) => void;
  onBack: () => void;
}

const DeviceSelector: React.FC<DeviceSelectorProps> = ({ onSelect, onBack }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full bg-slate-900 p-8">
      <h2 className="text-3xl font-bold text-white mb-8">Select Your Device</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
        {/* Mobile Mode Card */}
        <div 
          onClick={() => onSelect(DeviceType.HP)}
          className="group cursor-pointer bg-slate-800 border-2 border-slate-700 hover:border-blue-500 p-8 rounded-2xl flex flex-col items-center transition-all transform hover:-translate-y-2"
        >
          <div className="w-20 h-32 bg-slate-700 rounded-xl mb-4 border-2 border-slate-600 group-hover:bg-blue-900/50 transition-colors flex items-center justify-center">
            <div className="w-1 h-1 bg-slate-500 rounded-full mb-1"></div>
            <div className="w-12 h-20 border border-slate-500 rounded-sm"></div>
          </div>
          <h3 className="text-2xl font-bold text-white">Smartphone</h3>
          <p className="text-slate-400 text-center mt-2">Portrait UI, responsive apps, mobility focused.</p>
        </div>

        {/* PC Mode Card */}
        <div 
          onClick={() => onSelect(DeviceType.PC)}
          className="group cursor-pointer bg-slate-800 border-2 border-slate-700 hover:border-cyan-500 p-8 rounded-2xl flex flex-col items-center transition-all transform hover:-translate-y-2"
        >
          <div className="w-40 h-28 bg-slate-700 rounded-lg mb-4 border-2 border-slate-600 group-hover:bg-cyan-900/50 transition-colors flex flex-col items-center justify-center p-2">
             <div className="w-full h-full border border-slate-500 rounded-sm"></div>
             <div className="w-12 h-1 bg-slate-600 mt-1"></div>
             <div className="w-20 h-1 bg-slate-600 mt-1"></div>
          </div>
          <h3 className="text-2xl font-bold text-white">Laptop / PC</h3>
          <p className="text-slate-400 text-center mt-2">Landscape OS, advanced tools, high efficiency.</p>
        </div>
      </div>

      <button 
        onClick={onBack}
        className="mt-12 text-slate-400 hover:text-white transition-colors"
      >
        &larr; Back to Main Menu
      </button>
    </div>
  );
};

export default DeviceSelector;
