
import React, { useState, useEffect } from 'react';
import { GameState, Item } from '../../types';
import { MARKET_ITEMS, FOOD_ITEMS } from '../../constants';
import { 
  ChatBubbleBottomCenterTextIcon, 
  CameraIcon, 
  WalletIcon, 
  ShoppingCartIcon, 
  ChartBarIcon, 
  EnvelopeIcon,
  ChevronLeftIcon,
  SignalIcon,
  WifiIcon,
  Battery100Icon,
  PaperAirplaneIcon,
  TruckIcon,
  UserCircleIcon,
  ArrowTrendingUpIcon,
  PhotoIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';

interface HPModeProps {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  onBuyItem: (item: Item) => boolean;
  onMainMenu: () => void;
}

const HPMode: React.FC<HPModeProps> = ({ gameState, setGameState, onBuyItem, onMainMenu }) => {
  const [activeApp, setActiveApp] = useState<string | null>(null);
  const [time, setTime] = useState(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

  useEffect(() => {
    const t = setInterval(() => setTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })), 60000);
    return () => clearInterval(t);
  }, []);

  const apps = [
    { name: 'Pesan', icon: ChatBubbleBottomCenterTextIcon, color: 'bg-green-500' },
    { name: 'GoFood', icon: TruckIcon, color: 'bg-yellow-600' },
    { name: 'DanaPay', icon: WalletIcon, color: 'bg-blue-600' },
    { name: 'MarketShop', icon: ShoppingCartIcon, color: 'bg-orange-500' },
    { name: 'CreatorStats', icon: ChartBarIcon, color: 'bg-indigo-500' },
    { name: 'Mail', icon: EnvelopeIcon, color: 'bg-red-500' },
    { name: 'Kamera', icon: CameraIcon, color: 'bg-slate-400' },
  ];

  const renderApp = () => {
    switch (activeApp) {
      case 'Kamera':
        return (
          <div className="h-full bg-black flex flex-col items-center justify-center relative overflow-hidden">
             <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center"></div>
             <div className="z-10 text-center">
                <div className="w-24 h-24 border-2 border-white/20 rounded-full flex items-center justify-center mb-4">
                   <div className="w-20 h-20 bg-white/10 rounded-full animate-pulse backdrop-blur-md"></div>
                </div>
                <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] opacity-60">Camera Preview</p>
             </div>
             <div className="absolute bottom-10 flex space-x-10 items-center z-20">
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center"><PhotoIcon className="w-5 h-5" /></div>
                <div className="w-16 h-16 rounded-full bg-white border-4 border-slate-300 shadow-xl active:scale-90 transition-all"></div>
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center"><ArrowPathIcon className="w-5 h-5" /></div>
             </div>
          </div>
        );
      case 'CreatorStats':
        return (
          <div className="p-8 h-full bg-slate-900 text-white overflow-y-auto pb-20">
             <h2 className="text-2xl font-black mb-8 uppercase tracking-tighter italic">Mobile Studio</h2>
             <div className="space-y-6">
                <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                   <p className="text-[9px] font-black text-slate-500 uppercase mb-1">Subscribers</p>
                   <p className="text-3xl font-black">{gameState.stats.subscribers.toLocaleString()}</p>
                </div>
                <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                   <p className="text-[9px] font-black text-slate-500 uppercase mb-1">Energy Level</p>
                   <div className="flex items-center space-x-3">
                      <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                         <div className="h-full bg-blue-500" style={{ width: `${gameState.stats.energy}%` }}></div>
                      </div>
                      <span className="text-xs font-black">{Math.floor(gameState.stats.energy)}%</span>
                   </div>
                </div>
                <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                   <h3 className="text-[10px] font-black uppercase text-slate-400 mb-4 tracking-widest">Recent Activity</h3>
                   <div className="space-y-4">
                      {gameState.uploadedVideos.slice(0, 3).map(v => (
                        <div key={v.id} className="flex justify-between items-center">
                           <div>
                              <p className="text-[11px] font-bold truncate w-32">{v.title}</p>
                              <p className="text-[8px] text-slate-500 font-black uppercase">{v.status}</p>
                           </div>
                           <span className="text-[10px] font-black">{v.views.toLocaleString()} VIEWS</span>
                        </div>
                      ))}
                      {gameState.uploadedVideos.length === 0 && <p className="text-[10px] text-slate-600 font-bold uppercase">No data.</p>}
                   </div>
                </div>
             </div>
          </div>
        );
      case 'GoFood':
        return (
          <div className="p-6 h-full bg-slate-50 overflow-y-auto pb-20">
             <div className="flex justify-between items-end mb-8">
                <h2 className="text-2xl font-black text-emerald-600 italic tracking-tighter">GoFood</h2>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Deliver to Room</span>
             </div>
             <div className="space-y-5">
                {FOOD_ITEMS.map(food => (
                   <div key={food.id} className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm flex items-center space-x-5 active:scale-95 transition-all">
                      <div className="text-5xl drop-shadow-sm">{food.id === 'food_1' ? '🍜' : food.id === 'food_2' ? '🍛' : food.id === 'food_3' ? '🥩' : '☕'}</div>
                      <div className="flex-1">
                         <p className="text-sm font-black text-slate-800">{food.name}</p>
                         <div className="flex space-x-2 mt-1">
                            <p className="text-[9px] text-emerald-600 font-black uppercase tracking-tighter">+{food.hunger} Hunger</p>
                            <p className="text-[9px] text-blue-600 font-black uppercase tracking-tighter">+{food.energy} Energy</p>
                         </div>
                      </div>
                      <button 
                        onClick={() => {
                          if (gameState.stats.decon >= food.price) {
                             setGameState(prev => ({
                                ...prev,
                                stats: { 
                                   ...prev.stats, 
                                   decon: prev.stats.decon - food.price, 
                                   hunger: Math.min(100, prev.stats.hunger + food.hunger), 
                                   energy: Math.min(100, prev.stats.energy + food.energy) 
                                }
                             }));
                          }
                        }}
                        className="bg-emerald-600 text-white px-5 py-3 rounded-2xl text-[10px] font-black uppercase shadow-lg shadow-emerald-900/20"
                      >
                         {food.price}
                      </button>
                   </div>
                ))}
             </div>
          </div>
        );
      case 'DanaPay':
        return (
          <div className="p-8 h-full flex flex-col bg-blue-600 text-white">
             <div className="mt-12 mb-10 text-center">
                <p className="text-blue-100 text-[9px] opacity-75 uppercase font-black tracking-[0.3em] mb-1">Saldo DanaPay</p>
                <h2 className="text-4xl font-black tracking-tighter">{Math.floor(gameState.stats.decon).toLocaleString()} DECON</h2>
                <div className="inline-block mt-4 bg-white/20 px-4 py-1 rounded-full text-[9px] font-black uppercase backdrop-blur-md">
                   SALDO: {Math.floor(gameState.stats.saldo).toLocaleString()}
                </div>
             </div>
             <div className="flex-1 bg-white rounded-t-[3.5rem] p-10 text-slate-900 space-y-10 shadow-2xl overflow-y-auto pb-24 relative">
                <div className="grid grid-cols-4 gap-4">
                   {['Isi', 'Tarik', 'Scan', 'Voucher'].map(t => (
                     <div key={t} className="flex flex-col items-center">
                        <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-2xl mb-2 shadow-sm">
                           {t === 'Isi' ? '📥' : t === 'Tarik' ? '📤' : t === 'Scan' ? '📸' : '🎟️'}
                        </div>
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t}</span>
                     </div>
                   ))}
                </div>
                <div 
                   onClick={() => {
                      if (gameState.stats.saldo > 0) {
                        const amt = gameState.stats.saldo;
                        setGameState(prev => ({
                           ...prev,
                           stats: { ...prev.stats, saldo: 0, decon: prev.stats.decon + amt }
                        }));
                      }
                   }}
                   className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 cursor-pointer active:scale-95 transition-all group"
                >
                   <p className="text-[10px] font-black text-slate-400 uppercase mb-2">Withdraw to Decon</p>
                   <p className="text-xs font-bold text-blue-600 group-hover:underline">Klik untuk menarik semua SALDO ke DECON &rarr;</p>
                </div>
                <div>
                   <h3 className="font-black text-xs text-slate-400 uppercase mb-6 tracking-widest">Aktivitas Terakhir</h3>
                   <div className="space-y-6">
                      {gameState.transactions.slice(0, 5).map((t, i) => (
                        <div key={i} className="flex justify-between items-center text-xs">
                           <div>
                              <p className="font-black text-slate-800 uppercase tracking-tight text-[11px]">{t.description}</p>
                              <p className="text-[9px] text-slate-400 font-bold">{t.timestamp}</p>
                           </div>
                           <span className={`font-black tracking-tighter ${t.type === 'income' || t.type === 'withdrawal' ? 'text-emerald-600' : 'text-red-600'}`}>
                              {t.type === 'income' ? '+' : '-'}{t.amount.toLocaleString()}
                           </span>
                        </div>
                      ))}
                      {gameState.transactions.length === 0 && <p className="text-[10px] text-slate-400 font-bold uppercase text-center mt-10">Belum ada riwayat.</p>}
                   </div>
                </div>
             </div>
          </div>
        );
      case 'Pesan':
        return (
          <div className="h-full bg-slate-950 flex flex-col pb-20 overflow-hidden">
             <div className="p-6 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                <h2 className="text-xl font-black text-white uppercase tracking-tighter">Chat</h2>
                <PaperAirplaneIcon className="w-5 h-5 text-blue-500" />
             </div>
             <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {['Faiz', 'Indie Realm', 'Jian', 'Ahmad', 'Mom'].map((user, i) => (
                   <div key={user} className="bg-white/5 p-4 rounded-3xl border border-white/5 flex items-center space-x-4 active:bg-white/10 transition-all cursor-pointer">
                      <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center font-black text-white">{user[0]}</div>
                      <div className="flex-1 overflow-hidden">
                         <div className="flex justify-between items-center">
                            <span className="text-xs font-black text-white uppercase tracking-tighter">{user}</span>
                            <span className="text-[9px] text-slate-600 font-black">2M AGO</span>
                         </div>
                         <p className="text-[11px] text-slate-400 truncate mt-1">Gimana kabarnya Ryu? Udah upload belum?</p>
                      </div>
                      <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
                   </div>
                ))}
             </div>
          </div>
        );
      case 'Mail':
        return (
          <div className="h-full bg-slate-900 overflow-y-auto pb-20">
             <div className="p-8 border-b border-slate-800 flex justify-between items-center bg-slate-950/20">
                <h2 className="text-2xl font-black text-white uppercase tracking-tighter">MailBox</h2>
                <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-xs shadow-lg">✉️</div>
             </div>
             <div className="divide-y divide-slate-800">
                {gameState.messages.map(msg => (
                   <div key={msg.id} className="p-8 hover:bg-slate-800 active:bg-slate-700 transition-colors group">
                      <div className="flex justify-between mb-2">
                         <span className="font-black text-[11px] text-blue-400 uppercase tracking-widest group-hover:text-blue-300 transition-colors">{msg.sender}</span>
                         <span className="text-[9px] text-slate-600 font-black tracking-widest">{msg.timestamp}</span>
                      </div>
                      <p className="text-[13px] text-slate-200 font-bold leading-relaxed">{msg.content}</p>
                   </div>
                ))}
                {gameState.messages.length === 0 && <p className="p-10 text-center text-slate-600 text-xs font-black uppercase">No mail.</p>}
             </div>
          </div>
        );
      case 'MarketShop':
        return (
          <div className="p-6 bg-slate-900 h-full overflow-y-auto pb-24">
             <h2 className="text-2xl font-black text-white uppercase tracking-tighter mb-8 italic">MarketShop</h2>
             <div className="grid grid-cols-1 gap-4">
                {MARKET_ITEMS.map(it => {
                   const owned = gameState.inventory.includes(it.id);
                   return (
                      <div key={it.id} className="bg-slate-800/60 p-6 rounded-[2.5rem] border border-white/5 flex justify-between items-center group active:scale-95 transition-all">
                         <div className="flex-1">
                            <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest mb-1">{it.category}</p>
                            <p className="text-sm font-black text-white leading-tight mb-1">{it.name}</p>
                            <p className="text-[9px] text-blue-400 font-black uppercase tracking-tighter">+{it.qualityBonus} Quality Bonus</p>
                         </div>
                         <div className="text-right">
                           <p className="text-xs font-black text-emerald-400 mb-2 tracking-tighter">{it.price.toLocaleString()} DECON</p>
                           <button 
                              disabled={owned || gameState.stats.decon < it.price}
                              onClick={() => onBuyItem(it)}
                              className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase shadow-lg transition-all ${owned ? 'bg-slate-700 text-slate-500' : 'bg-orange-600 text-white hover:bg-orange-500 active:scale-90'}`}
                           >
                              {owned ? 'OWNED' : 'BELI'}
                           </button>
                         </div>
                      </div>
                   )
                })}
             </div>
          </div>
        );
      default:
        return <div className="p-20 text-center text-white/10 uppercase font-black tracking-[0.4em] text-[10px] mt-20">System Logic Required</div>;
    }
  };

  return (
    <div className="h-full w-full flex items-center justify-center bg-[#0f172a] p-4">
      <div className="relative w-full max-w-[400px] h-[820px] max-h-[96vh] bg-black rounded-[4.5rem] border-[12px] border-slate-800 shadow-[0_50px_100px_-20px_rgba(0,0,0,1)] overflow-hidden flex flex-col">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-9 bg-slate-800 rounded-b-[2.5rem] z-[100] flex items-center justify-center shadow-inner">
           <div className="w-14 h-1.5 bg-black rounded-full opacity-40"></div>
           <div className="w-2.5 h-2.5 bg-slate-900 rounded-full ml-4 border border-white/5"></div>
        </div>
        
        <div className="h-12 flex justify-between items-center px-10 pt-6 text-[11px] text-white z-40 font-black tracking-widest">
           <span>{time}</span>
           <div className="flex items-center space-x-3">
              <SignalIcon className="w-3.5 h-3.5" />
              <WifiIcon className="w-3.5 h-3.5" />
              <div className="flex items-center space-x-1 border border-white/20 px-1.5 py-0.5 rounded-md bg-white/5">
                 <Battery100Icon className="w-3.5 h-3.5 text-emerald-500" />
                 <span className="text-[9px]">100%</span>
              </div>
           </div>
        </div>

        <div className="flex-1 overflow-hidden relative">
          {!activeApp ? (
            <div className="h-full pt-20 px-10 grid grid-cols-4 gap-y-12 gap-x-5 content-start animate-in fade-in duration-700">
               {apps.map(app => (
                 <div key={app.name} onClick={() => setActiveApp(app.name)} className="flex flex-col items-center cursor-pointer group">
                    <div className={`w-15 h-15 ${app.color} rounded-[1.6rem] flex items-center justify-center shadow-2xl group-active:scale-90 transition-all border border-white/10 p-3`}>
                       <app.icon className="w-full h-full text-white drop-shadow-lg" />
                    </div>
                    <span className="mt-3 text-[9px] font-black text-white uppercase tracking-widest text-center leading-tight opacity-80 group-hover:opacity-100">{app.name}</span>
                 </div>
               ))}
               
               <div className="absolute bottom-10 left-8 right-8 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] p-6 flex justify-around items-center shadow-2xl z-10">
                  <div className="text-center">
                     <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Energy</p>
                     <p className="text-xs font-black text-blue-500">{Math.floor(gameState.stats.energy)}%</p>
                  </div>
                  <div className="w-[1px] h-6 bg-white/10"></div>
                  <div className="text-center">
                     <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Hunger</p>
                     <p className="text-xs font-black text-yellow-500">{Math.floor(gameState.stats.hunger)}%</p>
                  </div>
                  <div className="w-[1px] h-6 bg-white/10"></div>
                  <div className="text-center">
                     <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Day</p>
                     <p className="text-xs font-black text-white">{gameState.stats.day}</p>
                  </div>
               </div>
            </div>
          ) : (
            <div className="h-full bg-slate-950 flex flex-col animate-in slide-in-from-bottom-20 duration-500">
               <div className="h-16 flex items-center px-6 bg-slate-900/80 backdrop-blur-md border-b border-white/5 shadow-lg">
                  <button onClick={() => setActiveApp(null)} className="p-2 hover:bg-white/10 rounded-xl transition-all">
                     <ChevronLeftIcon className="w-7 h-7 text-blue-500" />
                  </button>
                  <span className="ml-4 font-black text-sm text-white uppercase tracking-[0.2em]">{activeApp}</span>
               </div>
               <div className="flex-1 overflow-hidden relative">{renderApp()}</div>
            </div>
          )}
        </div>

        <div className="h-20 flex items-center justify-center pb-6 relative z-[100] bg-black/40 backdrop-blur-sm">
           <div 
              onClick={() => {
                if (activeApp) setActiveApp(null);
                else onMainMenu();
              }} 
              className="w-14 h-14 rounded-[1.5rem] bg-white/5 border border-white/10 flex items-center justify-center cursor-pointer active:scale-90 transition-all shadow-2xl hover:bg-white/10 group"
           >
              <div className="w-6 h-6 border-2 border-white/40 rounded-xl group-hover:border-white transition-colors"></div>
           </div>
           <div className="absolute bottom-3 h-1.5 w-36 bg-white/20 rounded-full shadow-inner"></div>
        </div>
      </div>
    </div>
  );
};

export default HPMode;
