
import React, { useState, useEffect } from 'react';
import { GameState, Item, GameItem, AppWindow } from '../../types';
import PCAppContainer from './PCAppContainer';
import { 
  GlobeAltIcon, 
  VideoCameraIcon, 
  ChatBubbleLeftRightIcon, 
  ShoppingCartIcon, 
  ChartBarIcon, 
  EnvelopeIcon, 
  FolderIcon, 
  Cog6ToothIcon,
  AcademicCapIcon,
  WalletIcon,
  PlayIcon,
  TruckIcon,
  CloudArrowUpIcon
} from '@heroicons/react/24/outline';

interface PCModeProps {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  onBuyItem: (item: Item) => boolean;
  onStartStream: (config: any) => void;
  onStopStream: () => void;
  onMainMenu: () => void;
  onBuyGame: (game: GameItem) => boolean;
  onWithdrawSaldo: (amount: number) => boolean;
}

const PCMode: React.FC<PCModeProps> = ({ gameState, setGameState, onBuyItem, onStartStream, onStopStream, onMainMenu, onBuyGame, onWithdrawSaldo }) => {
  const [openApps, setOpenApps] = useState<AppWindow[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  const openApp = (name: string) => {
    setOpenApps(prev => {
      const existing = prev.find(a => a.name === name);
      if (existing) {
        const maxZ = Math.max(...prev.map(a => a.zIndex), 50);
        return prev.map(a => a.name === name ? { ...a, minimized: false, zIndex: maxZ + 1 } : a);
      }
      const maxZ = prev.length > 0 ? Math.max(...prev.map(a => a.zIndex)) : 50;
      return [...prev, {
        name,
        minimized: false,
        maximized: false,
        zIndex: maxZ + 1,
        position: { x: 100 + (prev.length * 30), y: 50 + (prev.length * 30) }
      }];
    });
  };

  const closeApp = (name: string) => {
    setOpenApps(prev => prev.filter(a => a.name !== name));
  };

  const toggleMinimize = (name: string) => {
    setOpenApps(prev => prev.map(a => a.name === name ? { ...a, minimized: !a.minimized } : a));
  };

  const toggleMaximize = (name: string) => {
    setOpenApps(prev => prev.map(a => a.name === name ? { ...a, maximized: !a.maximized } : a));
  };

  const moveApp = (name: string, pos: { x: number; y: number }) => {
    setOpenApps(prev => prev.map(a => a.name === name ? { ...a, position: pos } : a));
  };

  const apps = [
    { name: 'Browser', icon: GlobeAltIcon, color: 'bg-blue-500' },
    { name: 'BloxTube Studio', icon: PlayIcon, color: 'bg-red-600' },
    { name: 'Streaming Studio', icon: VideoCameraIcon, color: 'bg-red-500' },
    { name: 'MarketShop', icon: ShoppingCartIcon, color: 'bg-emerald-500' },
    { name: 'Game Store', icon: Cog6ToothIcon, color: 'bg-indigo-600' },
    { name: 'Wallet App', icon: WalletIcon, color: 'bg-blue-600' },
    { name: 'GoFood', icon: TruckIcon, color: 'bg-yellow-600' },
    { name: 'Mail', icon: EnvelopeIcon, color: 'bg-yellow-500' },
    { name: 'WleChat', icon: ChatBubbleLeftRightIcon, color: 'bg-green-500' },
    { name: 'File Manager', icon: FolderIcon, color: 'bg-indigo-500' },
    { name: 'CreatorStats', icon: ChartBarIcon, color: 'bg-purple-600' },
  ];

  return (
    <div className="relative w-full h-screen bg-[#0f172a] overflow-hidden bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2070&auto=format&fit=crop)' }}>
      <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px]"></div>

      {/* Desktop Icons */}
      <div className="relative p-10 grid grid-cols-1 grid-flow-col auto-cols-max gap-6 h-[calc(100%-48px)] content-start">
        {apps.map(app => (
          <div 
            key={app.name}
            onClick={() => openApp(app.name)}
            className="group flex flex-col items-center justify-center w-24 h-28 rounded-3xl hover:bg-white/10 cursor-pointer transition-all active:scale-95"
          >
            <div className={`w-14 h-14 ${app.color} rounded-2xl flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform border border-white/10 shadow-black/40`}>
              <app.icon className="w-8 h-8 text-white drop-shadow-md" />
            </div>
            <span className="mt-3 text-[10px] font-black text-white drop-shadow-lg text-center px-1 uppercase tracking-tighter opacity-90 group-hover:opacity-100">
              {app.name}
            </span>
          </div>
        ))}
      </div>

      {/* App Windows */}
      {openApps.map(app => !app.minimized && (
        <PCAppContainer 
          key={app.name}
          appName={app.name} 
          onClose={() => closeApp(app.name)} 
          onMinimize={() => toggleMinimize(app.name)}
          maximized={app.maximized}
          onToggleMaximize={() => toggleMaximize(app.name)}
          position={app.position}
          onMove={(pos) => moveApp(app.name, pos)}
          zIndex={app.zIndex}
          gameState={gameState}
          setGameState={setGameState}
          onBuyItem={onBuyItem}
          onStartStream={onStartStream}
          onStopStream={onStopStream}
          onBuyGame={onBuyGame}
          onWithdrawSaldo={onWithdrawSaldo}
          onFocus={() => openApp(app.name)}
        />
      ))}

      {/* Taskbar */}
      <div className="absolute bottom-0 w-full h-14 bg-slate-900/80 backdrop-blur-3xl border-t border-white/5 flex items-center px-6 justify-between z-[2000] shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        <div className="flex items-center space-x-3">
          <button onClick={onMainMenu} className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center hover:bg-blue-500 transition-all shadow-xl active:scale-90 border border-white/10">
             <div className="grid grid-cols-2 gap-1 p-2">
               <div className="w-1.5 h-1.5 bg-white rounded-sm"></div>
               <div className="w-1.5 h-1.5 bg-white rounded-sm opacity-50"></div>
               <div className="w-1.5 h-1.5 bg-white rounded-sm opacity-50"></div>
               <div className="w-1.5 h-1.5 bg-white rounded-sm"></div>
             </div>
          </button>
          <div className="h-6 w-[1px] bg-white/10 mx-2"></div>
          <div className="flex space-x-2">
            {openApps.map(app => (
              <button 
                key={app.name}
                onClick={() => toggleMinimize(app.name)} 
                className={`h-11 px-5 flex items-center space-x-3 rounded-2xl transition-all border-b-2 active:scale-95 ${app.minimized ? 'bg-slate-800/40 border-transparent opacity-60' : 'bg-slate-700/60 border-blue-500 shadow-lg'}`}
              >
                <span className="text-[10px] text-white font-black uppercase tracking-widest">{app.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center space-x-6 text-xs font-medium text-slate-300">
          <div className="flex space-x-5 items-center border-r border-white/10 pr-6">
             <div className="flex flex-col items-center">
                <span className="text-[7px] text-slate-500 uppercase font-black tracking-widest mb-1">Energy</span>
                <div className="w-14 h-1.5 bg-black/40 rounded-full overflow-hidden border border-white/5">
                   <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${gameState.stats.energy}%` }}></div>
                </div>
             </div>
             <div className="flex flex-col items-center">
                <span className="text-[7px] text-slate-500 uppercase font-black tracking-widest mb-1">Hunger</span>
                <div className="w-14 h-1.5 bg-black/40 rounded-full overflow-hidden border border-white/5">
                   <div className="h-full bg-yellow-500 transition-all duration-1000" style={{ width: `${gameState.stats.hunger}%` }}></div>
                </div>
             </div>
          </div>
          
          <div className="flex flex-col items-end border-r border-white/10 pr-6">
            <span className="text-white text-[11px] font-black">{currentTime}</span>
            <span className="text-[8px] uppercase font-black tracking-widest text-slate-500">Day {gameState.stats.day}</span>
          </div>

          <div className="flex items-center space-x-2">
             <div className="flex items-center bg-emerald-500/10 px-4 py-2 rounded-2xl border border-emerald-500/20 shadow-inner">
                <span className="text-emerald-400 mr-2 font-black text-[10px] uppercase">Decon</span>
                <span className="text-white font-black font-mono tracking-tighter">{Math.floor(gameState.stats.decon).toLocaleString()}</span>
             </div>
             <button 
               onClick={() => alert("Game Berhasil Disimpan Otomatis!")}
               className="p-2 bg-blue-600 hover:bg-blue-500 rounded-xl transition-all shadow-lg border border-white/10"
               title="Simpan Game"
             >
                <CloudArrowUpIcon className="w-5 h-5 text-white" />
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PCMode;
