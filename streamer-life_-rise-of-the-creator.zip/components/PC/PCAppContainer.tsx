
import React, { useState, useRef, useEffect } from 'react';
import { GameState, Item, GameItem, VideoEntry, Message } from '../../types';
import { MARKET_ITEMS, GAME_STORE_ITEMS, FOOD_ITEMS } from '../../constants';
import { 
  XMarkIcon, 
  MinusIcon, 
  Square2StackIcon,
  PlayIcon,
  DocumentTextIcon,
  PhotoIcon,
  ArrowPathIcon,
  VideoCameraIcon,
  ChatBubbleLeftRightIcon,
  Cog6ToothIcon,
  ChartBarIcon,
  WalletIcon,
  ArrowTrendingUpIcon,
  CloudArrowUpIcon,
  ChevronLeftIcon,
  TruckIcon,
  EnvelopeIcon,
  PaperAirplaneIcon,
  UserCircleIcon,
  ComputerDesktopIcon
} from '@heroicons/react/24/solid';

interface AppContainerProps {
  appName: string;
  onClose: () => void;
  onMinimize: () => void;
  maximized: boolean;
  onToggleMaximize: () => void;
  position: { x: number, y: number };
  onMove: (pos: { x: number, y: number }) => void;
  zIndex: number;
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  onBuyItem: (item: Item) => boolean;
  onStartStream: (config: any) => void;
  onStopStream: () => void;
  onBuyGame: (game: GameItem) => boolean;
  onWithdrawSaldo: (amount: number) => boolean;
  onFocus: () => void;
}

const PCAppContainer: React.FC<AppContainerProps> = ({ 
  appName, onClose, onMinimize, maximized, onToggleMaximize, position, onMove, zIndex, gameState, setGameState, onBuyItem, onStartStream, onStopStream, onBuyGame, onWithdrawSaldo, onFocus 
}) => {
  const [streamConfig, setStreamConfig] = useState({ gameId: GAME_STORE_ITEMS[0].id, resolution: '1080p' });
  const [isDragging, setIsDragging] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });
  
  // App specific states
  const [browserUrl, setBrowserUrl] = useState('');
  const [selectedMail, setSelectedMail] = useState<Message | null>(null);
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [walletNominal, setWalletNominal] = useState<string>('50000');
  const [chatInput, setChatInput] = useState('');
  const [selectedChatUser, setSelectedChatUser] = useState('Faiz');

  const handleMouseDown = (e: React.MouseEvent) => {
    onFocus();
    if (maximized) return;
    if ((e.target as HTMLElement).closest('button')) return; // Don't drag if clicking buttons
    setIsDragging(true);
    dragOffset.current = { x: e.clientX - position.x, y: e.clientY - position.y };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      onMove({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
    };
    const handleMouseUp = () => setIsDragging(false);
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const handleRecordVideo = (gameId: string) => {
    if (gameState.stats.energy < 20 || gameState.stats.hunger < 15) return;
    const newVideo: VideoEntry = {
      id: Date.now().toString(),
      title: `Recording: ${gameId}`,
      views: 0,
      targetViews: Math.floor(gameState.stats.subscribers * 0.45) + Math.floor(Math.random() * 200 + 50),
      likes: 0,
      subsGained: 0,
      adsenseEarned: 0,
      uploadDate: new Date().toISOString(),
      gameId,
      status: 'raw',
      editProgress: 0
    };
    setGameState(prev => ({
      ...prev,
      uploadedVideos: [newVideo, ...prev.uploadedVideos],
      stats: { ...prev.stats, energy: prev.stats.energy - 20, hunger: prev.stats.hunger - 15 }
    }));
  };

  const handleEditVideo = (id: string) => {
    setGameState(prev => {
      const videos = prev.uploadedVideos.map(v => {
        if (v.id === id && v.status === 'raw') {
          return { ...v, status: 'editing', editProgress: 1 };
        }
        return v;
      });
      return { ...prev, uploadedVideos: videos as VideoEntry[] };
    });

    const interval = setInterval(() => {
      setGameState(prev => {
        let done = false;
        const videos = prev.uploadedVideos.map(v => {
          if (v.id === id && v.status === 'editing') {
            const nextProgress = v.editProgress + 15;
            if (nextProgress >= 100) {
              done = true;
              return { ...v, status: 'ready', editProgress: 100 };
            }
            return { ...v, editProgress: nextProgress };
          }
          return v;
        });
        if (done) clearInterval(interval);
        return { ...prev, uploadedVideos: videos as VideoEntry[] };
      });
    }, 800);
  };

  const handleUploadVideo = (id: string) => {
    setGameState(prev => ({
      ...prev,
      uploadedVideos: prev.uploadedVideos.map(v => v.id === id ? { ...v, status: 'uploaded' } : v) as VideoEntry[]
    }));
  };

  const renderAppContent = () => {
    switch (appName) {
      case 'File Manager':
        return (
          <div className="flex h-full bg-slate-100 text-slate-800">
             <div className="w-48 bg-slate-200 p-4 border-r border-slate-300">
                <h5 className="text-[10px] font-black uppercase text-slate-400 mb-4 tracking-widest">This PC</h5>
                <ul className="space-y-1">
                   <li className="text-xs font-bold p-2 hover:bg-blue-100 rounded-lg cursor-pointer text-blue-600">Inventory</li>
                   <li className="text-xs font-bold p-2 hover:bg-blue-100 rounded-lg cursor-pointer">Videos</li>
                   <li className="text-xs font-bold p-2 hover:bg-blue-100 rounded-lg cursor-pointer">Downloads</li>
                </ul>
             </div>
             <div className="flex-1 p-8 grid grid-cols-4 content-start gap-8">
                {gameState.inventory.map(itemId => {
                   const item = MARKET_ITEMS.find(m => m.id === itemId);
                   return (
                      <div key={itemId} className="flex flex-col items-center group">
                         <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-slate-200 flex items-center justify-center group-hover:border-blue-500 transition-all">
                            <Cog6ToothIcon className="w-8 h-8 text-blue-500" />
                         </div>
                         <span className="text-[9px] font-black mt-2 text-center uppercase leading-tight">{item?.name}</span>
                      </div>
                   )
                })}
                {gameState.inventory.length === 0 && <p className="col-span-4 text-center text-slate-400 text-xs mt-20">No items found.</p>}
             </div>
          </div>
        );

      case 'Browser':
        return (
          <div className="flex flex-col h-full bg-slate-50">
            <div className="h-10 bg-slate-200 flex items-center px-4 space-x-2 border-b border-slate-300">
              <button onClick={() => setBrowserUrl('')} className="p-1 hover:bg-slate-300 rounded"><ChevronLeftIcon className="w-4 h-4 text-slate-600" /></button>
              <div className="flex-1 bg-white rounded-lg px-3 py-1 text-[10px] text-slate-600 border border-slate-300 flex items-center">
                <span className="opacity-50 mr-1">https://</span>{browserUrl || 'onesearch.local'}
              </div>
              <ArrowPathIcon className="w-3 h-3 text-slate-400 cursor-pointer" />
            </div>
            <div className="flex-1 p-6 text-slate-800 overflow-y-auto">
              {!browserUrl ? (
                <div className="max-w-xl mx-auto space-y-10 py-10">
                  <div className="text-center">
                    <h1 className="text-5xl font-black text-blue-600 mb-2 tracking-tighter uppercase italic">OneSearch</h1>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.4em]">Indie Creative Gateway</p>
                  </div>
                  <div className="relative">
                    <input type="text" className="w-full bg-white border-2 border-slate-200 rounded-full px-6 py-4 shadow-xl focus:outline-none focus:border-blue-500 transition-all font-bold" placeholder="Cari info sponsor, gear, atau komunitas..." />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div onClick={() => setBrowserUrl('indie-realm.mgx.world')} className="p-8 bg-white border-2 border-slate-100 rounded-[2rem] hover:border-indigo-500 cursor-pointer transition-all shadow-sm hover:shadow-xl group">
                       <h4 className="font-black text-indigo-600 group-hover:scale-105 transition-transform">INDIE REALM</h4>
                       <p className="text-[10px] text-slate-500 mt-2 leading-relaxed">Pusat game indie dan komunitas kreator dunia.</p>
                    </div>
                    <div onClick={() => setBrowserUrl('streamer-tips.net')} className="p-8 bg-white border-2 border-slate-100 rounded-[2rem] hover:border-blue-500 cursor-pointer transition-all shadow-sm hover:shadow-xl group">
                       <h4 className="font-black text-blue-600 group-hover:scale-105 transition-transform">CREATOR TIPS</h4>
                       <p className="text-[10px] text-slate-500 mt-2 leading-relaxed">Rahasia menembus 1 Juta subscriber dengan cepat.</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-3xl p-10 shadow-2xl border border-slate-100 max-w-3xl mx-auto">
                   <h2 className="text-3xl font-black text-indigo-700 mb-2">{browserUrl.toUpperCase()}</h2>
                   <div className="h-1 w-20 bg-indigo-500 mb-8 rounded-full"></div>
                   <div className="space-y-6 text-slate-600 text-sm leading-relaxed">
                      <p>Selamat datang di portal <span className="font-bold text-slate-900">{browserUrl}</span>. Kami sedang dalam tahap optimalisasi untuk memberikan pengalaman terbaik bagi kreator.</p>
                      <div className="p-6 bg-slate-50 rounded-2xl border-l-4 border-indigo-500">
                         <p className="italic font-medium">"Kunci kesuksesan seorang kreator adalah konsistensi dan kemampuan beradaptasi dengan tren terbaru."</p>
                      </div>
                      <p>Dapatkan update terbaru setiap harinya melalui aplikasi Mail dan WleChat di OS OneComplier Anda.</p>
                   </div>
                   <button onClick={() => setBrowserUrl('')} className="mt-12 bg-indigo-600 text-white px-8 py-3 rounded-xl font-black uppercase text-xs shadow-lg hover:bg-indigo-500 transition-all">Kembali</button>
                </div>
              )}
            </div>
          </div>
        );

      case 'BloxTube Studio':
        return (
          <div className="flex h-full bg-slate-900 text-white">
             <div className="w-56 bg-slate-950 p-6 space-y-4 border-r border-white/5">
                <nav className="space-y-2 mt-4">
                   {['Dashboard', 'Content', 'Analytics'].map(tab => (
                     <div 
                      key={tab} 
                      onClick={() => setActiveTab(tab)}
                      className={`text-[10px] p-4 rounded-2xl font-black cursor-pointer transition-all uppercase tracking-widest ${activeTab === tab ? 'bg-red-600 text-white shadow-lg' : 'text-slate-500 hover:bg-white/5'}`}
                     >
                       {tab}
                     </div>
                   ))}
                </nav>
             </div>
             <div className="flex-1 p-8 overflow-y-auto">
                <div className="flex justify-between items-center mb-10">
                   <h2 className="text-3xl font-black uppercase tracking-tighter">{activeTab}</h2>
                   <div className="flex space-x-2">
                      {gameState.ownedGames.map(gid => {
                        const g = GAME_STORE_ITEMS.find(it => it.id === gid);
                        return (
                          <button 
                            key={gid} 
                            onClick={() => handleRecordVideo(gid)}
                            className="bg-red-600 hover:bg-red-500 px-5 py-3 rounded-2xl text-[10px] font-black uppercase transition-all shadow-xl shadow-red-900/20"
                          >
                             REC {g?.name}
                          </button>
                        );
                      })}
                   </div>
                </div>
                {activeTab === 'Analytics' ? (
                   <div className="grid grid-cols-2 gap-6">
                      <div className="bg-white/5 p-8 rounded-[2rem] border border-white/5">
                         <p className="text-[10px] font-black text-slate-500 uppercase mb-2">Total Views</p>
                         <p className="text-4xl font-black">{gameState.uploadedVideos.reduce((acc, v) => acc + v.views, 0).toLocaleString()}</p>
                      </div>
                      <div className="bg-white/5 p-8 rounded-[2rem] border border-white/5">
                         <p className="text-[10px] font-black text-slate-500 uppercase mb-2">Adsense Earned</p>
                         <p className="text-4xl font-black text-emerald-500">{gameState.uploadedVideos.reduce((acc, v) => acc + v.adsenseEarned, 0).toLocaleString()} DECON</p>
                      </div>
                   </div>
                ) : (
                   <div className="space-y-4">
                      {gameState.uploadedVideos.length === 0 && <p className="text-center text-slate-600 py-20 font-bold uppercase text-[10px] tracking-widest">Belum ada konten.</p>}
                      {gameState.uploadedVideos.map(vid => (
                        <div key={vid.id} className="bg-white/5 p-6 rounded-[2rem] border border-white/5 flex items-center justify-between hover:bg-white/10 transition-all group">
                           <div className="flex items-center space-x-6">
                              <div className="w-24 h-14 bg-black rounded-2xl flex items-center justify-center border border-white/10 group-hover:scale-105 transition-transform">
                                 <PlayIcon className="w-8 h-8 text-red-600" />
                              </div>
                              <div>
                                 <p className="text-sm font-black uppercase tracking-tight">{vid.title}</p>
                                 <div className="flex items-center space-x-3 mt-1">
                                    <span className={`text-[8px] font-black px-2.5 py-1 rounded-lg uppercase ${vid.status === 'raw' ? 'bg-blue-600' : vid.status === 'editing' ? 'bg-yellow-600 animate-pulse' : vid.status === 'ready' ? 'bg-green-600' : 'bg-slate-700 opacity-50'}`}>
                                       {vid.status}
                                    </span>
                                    <span className="text-[9px] text-slate-500 font-bold">{new Date(vid.uploadDate).toLocaleDateString()}</span>
                                 </div>
                              </div>
                           </div>
                           <div className="flex items-center space-x-6">
                              {vid.status === 'raw' && <button onClick={() => handleEditVideo(vid.id)} className="bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-2xl text-[10px] font-black uppercase shadow-lg">Edit</button>}
                              {vid.status === 'editing' && <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden shadow-inner"><div className="h-full bg-yellow-500" style={{ width: `${vid.editProgress}%` }}></div></div>}
                              {vid.status === 'ready' && <button onClick={() => handleUploadVideo(vid.id)} className="bg-green-600 hover:bg-green-500 px-6 py-3 rounded-2xl text-[10px] font-black uppercase shadow-lg">Upload</button>}
                              {vid.status === 'uploaded' && (
                                <div className="text-right">
                                   <p className="text-sm font-black">{vid.views.toLocaleString()} <span className="text-[10px] text-slate-500 font-normal ml-1">VIEWS</span></p>
                                   <p className="text-[10px] text-emerald-400 font-black mt-0.5">{vid.adsenseEarned.toLocaleString()} DECON EARNED</p>
                                </div>
                              )}
                           </div>
                        </div>
                      ))}
                   </div>
                )}
             </div>
          </div>
        );

      case 'GoFood':
        return (
          <div className="h-full bg-white p-8 text-slate-900 overflow-y-auto">
             <div className="flex justify-between items-center mb-10">
                <h2 className="text-4xl font-black text-emerald-600 italic tracking-tighter">GoFood</h2>
                <div className="flex items-center space-x-2 text-[10px] font-black uppercase text-slate-400">
                   <TruckIcon className="w-4 h-4" /> <span>Express Delivery</span>
                </div>
             </div>
             <div className="grid grid-cols-2 gap-8">
                {FOOD_ITEMS.map(food => (
                   <div key={food.id} className="bg-slate-50 p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col justify-between hover:shadow-2xl hover:-translate-y-1 transition-all group">
                      <div>
                         <div className="w-full h-40 bg-white rounded-[2rem] mb-6 flex items-center justify-center text-6xl group-hover:scale-110 transition-transform shadow-inner">
                            {food.id === 'food_1' ? '🍜' : food.id === 'food_2' ? '🍛' : food.id === 'food_3' ? '🥩' : '☕'}
                         </div>
                         <h4 className="font-black text-2xl mb-2">{food.name}</h4>
                         <div className="flex space-x-3">
                            <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full uppercase">+{food.hunger} Hunger</span>
                            <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-full uppercase">+{food.energy} Energy</span>
                         </div>
                      </div>
                      <div className="mt-10 flex justify-between items-center">
                         <span className="font-black text-xl text-slate-700 tracking-tighter">{food.price} DECON</span>
                         <button 
                           onClick={() => {
                              if (gameState.stats.decon >= food.price) {
                                 setGameState(prev => ({
                                    ...prev,
                                    stats: { 
                                       ...prev.stats, 
                                       decon: prev.stats.decon - food.price,
                                       hunger: Math.min(100, prev.stats.hunger + food.hunger),
                                       energy: Math.min(100, prev.stats.energy + food.energy)
                                    }
                                 }));
                              }
                           }}
                           className="bg-emerald-600 text-white px-8 py-4 rounded-[1.5rem] text-[10px] font-black uppercase hover:bg-emerald-500 shadow-xl shadow-emerald-900/20 active:scale-95 transition-all"
                         >
                            BELI SEKARANG
                         </button>
                      </div>
                   </div>
                ))}
             </div>
          </div>
        );

      case 'Wallet App':
        return (
          <div className="h-full bg-slate-900 p-10 text-white overflow-y-auto">
             <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black flex items-center uppercase tracking-tighter italic">
                  <WalletIcon className="w-10 h-10 mr-4 text-emerald-500" /> One Wallet
                </h2>
                <div className="text-[10px] font-black text-emerald-500 uppercase tracking-widest border border-emerald-500/30 px-3 py-1 rounded-full bg-emerald-500/10">Verified Safe</div>
             </div>
             
             <div className="grid grid-cols-2 gap-8 mb-10">
                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
                   <div className="absolute -right-4 -top-4 w-32 h-32 bg-white/10 rounded-full group-hover:scale-150 transition-transform"></div>
                   <p className="text-[10px] font-black uppercase opacity-60 tracking-widest">DECON Balance</p>
                   <p className="text-5xl font-black mt-2 tracking-tighter">{Math.floor(gameState.stats.decon).toLocaleString()}</p>
                </div>
                <div className="bg-gradient-to-br from-emerald-600 to-teal-700 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
                   <div className="absolute -right-4 -top-4 w-32 h-32 bg-white/10 rounded-full group-hover:scale-150 transition-transform"></div>
                   <p className="text-[10px] font-black uppercase opacity-60 tracking-widest">SALDO Balance</p>
                   <p className="text-5xl font-black mt-2 tracking-tighter">{Math.floor(gameState.stats.saldo).toLocaleString()}</p>
                   <button 
                     onClick={() => onWithdrawSaldo(gameState.stats.saldo)}
                     className="mt-6 w-full bg-white/20 hover:bg-white/30 p-3 rounded-2xl text-[10px] font-black uppercase transition-all backdrop-blur-md"
                   >
                     Withdraw to DECON
                   </button>
                </div>
             </div>

             <div className="bg-white/5 p-10 rounded-[2.5rem] border border-white/10 shadow-xl">
                <div className="flex justify-between items-center mb-8">
                   <h3 className="text-sm font-black uppercase tracking-widest">Isi Saldo (Top-up)</h3>
                   <span className="text-[10px] text-slate-500 font-bold italic">Fee: 20% (Rate: 1.2)</span>
                </div>
                <div className="flex space-x-4 mb-8">
                   <input 
                      type="number" 
                      value={walletNominal}
                      onChange={(e) => setWalletNominal(e.target.value)}
                      className="flex-1 bg-black/40 border-2 border-white/5 rounded-2xl px-6 py-4 text-xl font-black outline-none focus:border-emerald-500 transition-all"
                      placeholder="Masukkan nominal..."
                   />
                   <button 
                     onClick={() => {
                        const amt = parseInt(walletNominal);
                        if (amt > 0) {
                           const cost = amt * 1.2;
                           if (gameState.stats.decon >= cost) {
                              setGameState(prev => ({
                                 ...prev,
                                 stats: { ...prev.stats, decon: prev.stats.decon - cost, saldo: prev.stats.saldo + amt }
                              }));
                           } else {
                              alert("Saldo DECON tidak mencukupi!");
                           }
                        }
                     }}
                     className="bg-emerald-600 hover:bg-emerald-500 px-10 rounded-2xl font-black uppercase text-xs shadow-xl active:scale-95 transition-all"
                   >
                     TOPUP
                   </button>
                </div>
                <div className="grid grid-cols-4 gap-4">
                   {['50000', '100000', '250000', '500000'].map(n => (
                      <button key={n} onClick={() => setWalletNominal(n)} className="bg-white/5 hover:bg-white/10 p-3 rounded-xl text-[10px] font-black transition-all">{parseInt(n).toLocaleString()}</button>
                   ))}
                </div>
             </div>
          </div>
        );

      case 'WleChat':
        return (
          <div className="flex h-full bg-[#111b21]">
             <div className="w-80 border-r border-white/5 bg-[#111b21] flex flex-col">
                <div className="p-4 bg-[#202c33] flex justify-between items-center">
                   <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center font-black text-sm">R</div>
                   <div className="flex space-x-5 text-slate-400">
                      <ChatBubbleLeftRightIcon className="w-5 h-5 cursor-pointer hover:text-white" />
                      <Cog6ToothIcon className="w-5 h-5 cursor-pointer hover:text-white" />
                   </div>
                </div>
                <div className="p-3">
                   <div className="bg-[#202c33] p-3 rounded-xl flex items-center shadow-inner">
                      <input type="text" className="bg-transparent text-xs w-full text-slate-300 outline-none px-2" placeholder="Cari teman atau grup..." />
                   </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                   {['Faiz', 'Jian', 'Ahmad', 'Mom', 'Sponsor Indie'].map(user => (
                      <div 
                        key={user} 
                        onClick={() => setSelectedChatUser(user)}
                        className={`p-4 flex items-center space-x-4 cursor-pointer border-b border-white/5 transition-all ${selectedChatUser === user ? 'bg-[#2a3942]' : 'hover:bg-[#202c33]'}`}
                      >
                         <div className="w-12 h-12 rounded-full bg-slate-600 flex items-center justify-center font-black text-white shadow-lg">{user[0]}</div>
                         <div className="flex-1 overflow-hidden">
                            <div className="flex justify-between items-center">
                               <span className="text-sm font-black text-slate-100">{user}</span>
                               <span className="text-[9px] text-slate-500 font-bold uppercase">10:45 AM</span>
                            </div>
                            <p className="text-[11px] text-slate-400 truncate mt-1">Status: Sedang memikirkan ide konten...</p>
                         </div>
                      </div>
                   ))}
                </div>
             </div>
             <div className="flex-1 flex flex-col bg-[#0b141a] relative">
                {/* Background Pattern Placeholder */}
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[url('https://w0.peakpx.com/wallpaper/818/148/HD-wallpaper-whatsapp-background-cool-dark-graphy-leaf-nature-theme-thumbnail.jpg')] bg-repeat"></div>
                
                <div className="p-4 bg-[#202c33] flex items-center justify-between border-b border-white/5 z-10">
                   <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-slate-600 flex items-center justify-center font-black">{selectedChatUser[0]}</div>
                      <div>
                        <p className="font-black text-sm text-slate-100">{selectedChatUser}</p>
                        <p className="text-[10px] text-emerald-500 font-bold">Online</p>
                      </div>
                   </div>
                </div>

                <div className="flex-1 p-8 space-y-6 overflow-y-auto z-10">
                   <div className="flex flex-col items-start animate-in fade-in slide-in-from-left-4">
                      <div className="bg-[#202c33] text-slate-200 p-4 rounded-2xl rounded-tl-none text-xs max-w-sm shadow-xl leading-relaxed">
                         Yo {selectedChatUser === 'Mom' ? 'sayang' : 'Ryu'}! Gimana kabar streaming hari ini? Denger-denger views lo lagi naik nih.
                      </div>
                      <span className="text-[8px] text-slate-500 mt-2 ml-1 font-bold">10:40 AM</span>
                   </div>
                   <div className="flex flex-col items-end animate-in fade-in slide-in-from-right-4">
                      <div className="bg-[#005c4b] text-white p-4 rounded-2xl rounded-tr-none text-xs max-w-sm shadow-xl leading-relaxed">
                         Iya nih, baru aja dapet sponsor dari Indie Realm juga. Doain moga lancar terus ya!
                      </div>
                      <span className="text-[8px] text-slate-500 mt-2 mr-1 font-bold">10:42 AM</span>
                   </div>
                </div>

                <div className="p-4 bg-[#202c33] flex items-center space-x-3 z-10">
                   <input 
                      type="text" 
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      className="flex-1 bg-[#2a3942] rounded-2xl px-6 py-4 text-xs text-slate-100 outline-none placeholder:text-slate-500 font-medium" 
                      placeholder="Ketik pesan..." 
                   />
                   <button 
                      onClick={() => setChatInput('')}
                      className="bg-[#00a884] p-4 rounded-2xl hover:scale-105 active:scale-90 transition-all shadow-lg"
                   >
                      <PaperAirplaneIcon className="w-5 h-5 text-white" />
                   </button>
                </div>
             </div>
          </div>
        );

      case 'CreatorStats':
        return (
          <div className="p-10 bg-slate-900 h-full overflow-y-auto">
             <div className="flex justify-between items-center mb-10">
                <h2 className="text-4xl font-black uppercase tracking-tighter italic">Dashboard Creator</h2>
                <div className="text-[10px] font-black text-blue-500 uppercase tracking-widest bg-blue-500/10 px-4 py-1.5 rounded-full border border-blue-500/20">Updated Live</div>
             </div>
             
             <div className="grid grid-cols-3 gap-8 mb-10">
                <div className="bg-white/5 p-8 rounded-[3rem] border border-white/10 shadow-xl">
                   <p className="text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest">Subscribers</p>
                   <p className="text-4xl font-black">{gameState.stats.subscribers.toLocaleString()}</p>
                   <div className="mt-4 flex items-center text-emerald-500 text-[10px] font-black">
                      <ArrowTrendingUpIcon className="w-4 h-4 mr-1" /> +12% Growth
                   </div>
                </div>
                <div className="bg-white/5 p-8 rounded-[3rem] border border-white/10 shadow-xl">
                   <p className="text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest">Total Likes</p>
                   <p className="text-4xl font-black">{gameState.uploadedVideos.reduce((acc, v) => acc + v.likes, 0).toLocaleString()}</p>
                </div>
                <div className="bg-white/5 p-8 rounded-[3rem] border border-white/10 shadow-xl">
                   <p className="text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest">Global Rank</p>
                   <p className="text-4xl font-black text-blue-500">#{gameState.stats.ranking}</p>
                </div>
             </div>

             <div className="bg-white/5 p-10 rounded-[3rem] border border-white/10">
                <h3 className="text-sm font-black uppercase mb-8 tracking-widest">Weekly Performance</h3>
                <div className="h-64 flex items-end space-x-6 px-4">
                   {[40, 65, 30, 85, 45, 95, 70].map((h, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center group">
                         <div 
                            className="w-full bg-blue-600/40 rounded-t-xl hover:bg-blue-500 transition-all duration-500 cursor-pointer shadow-lg" 
                            style={{ height: `${h}%` }}
                         ></div>
                         <span className="text-[8px] font-black mt-3 text-slate-500 uppercase">Day {i+1}</span>
                      </div>
                   ))}
                </div>
             </div>
          </div>
        );

      case 'Game Store':
        return (
          <div className="p-10 bg-slate-900 h-full overflow-y-auto">
             <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black uppercase tracking-tighter">OneStore Games</h2>
                <div className="text-[10px] font-black text-slate-500">DIGITAL LICENSES ONLY</div>
             </div>
             <div className="grid grid-cols-3 gap-8 pb-10">
                {GAME_STORE_ITEMS.map(game => {
                  const owned = gameState.ownedGames.includes(game.id);
                  return (
                    <div key={game.id} className="bg-white/5 border border-white/10 p-8 rounded-[3rem] flex flex-col justify-between group hover:border-indigo-500/50 transition-all hover:bg-white/[0.08] shadow-sm hover:shadow-2xl">
                       <div>
                          <div className="w-full aspect-video bg-black rounded-3xl mb-6 flex items-center justify-center text-white/10 group-hover:text-indigo-500 transition-colors shadow-inner overflow-hidden relative">
                             <Cog6ToothIcon className="w-16 h-16 group-hover:rotate-90 transition-transform duration-700" />
                             {game.quality === 3 && <div className="absolute top-4 right-4 bg-yellow-500 text-black text-[8px] font-black px-2 py-1 rounded-full uppercase">Top Rated</div>}
                          </div>
                          <h4 className="font-black text-xl mb-1">{game.name}</h4>
                          <div className="flex items-center space-x-1">
                             {Array.from({length: 3}).map((_, i) => (
                                <span key={i} className={i < game.quality ? "text-indigo-400 text-sm" : "text-slate-700 text-sm"}>★</span>
                             ))}
                          </div>
                       </div>
                       <div className="mt-8 flex justify-between items-center">
                          <span className="text-indigo-400 font-black tracking-tighter">{game.isFree ? 'FREE' : `${game.price.toLocaleString()} DECON`}</span>
                          <button 
                            disabled={owned || (gameState.stats.decon < game.price)}
                            onClick={() => onBuyGame(game)}
                            className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase shadow-lg transition-all active:scale-95 ${owned ? 'bg-slate-800 text-slate-600 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-500 text-white'}`}
                          >
                             {owned ? 'OWNED' : 'DOWNLOAD'}
                          </button>
                       </div>
                    </div>
                  );
                })}
             </div>
          </div>
        );

      case 'MarketShop':
        return (
          <div className="p-10 bg-slate-900 h-full overflow-y-auto">
             <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black uppercase tracking-tighter">Market Gear</h2>
                <p className="text-[10px] font-black text-slate-500">UPGRADE YOUR STUDIO QUALITY</p>
             </div>
             <div className="grid grid-cols-2 gap-8 pb-10">
                {MARKET_ITEMS.map(item => {
                  const owned = gameState.inventory.includes(item.id);
                  return (
                    <div key={item.id} className="bg-white/5 p-8 rounded-[3rem] border border-white/5 flex items-center space-x-8 hover:bg-white/10 transition-all group">
                       <div className="w-24 h-24 bg-black rounded-3xl flex items-center justify-center text-slate-800 group-hover:text-blue-500 transition-colors shadow-inner">
                          {item.category === 'Camera' && <VideoCameraIcon className="w-10 h-10" />}
                          {item.category === 'Microphone' && <ChatBubbleLeftRightIcon className="w-10 h-10" />}
                          {item.category === 'Lighting' && <ChartBarIcon className="w-10 h-10" />}
                          {item.category === 'Monitor' && <ComputerDesktopIcon className="w-10 h-10" />}
                          {item.category === 'PC' && <Cog6ToothIcon className="w-10 h-10" />}
                          {item.category === 'Furniture' && <UserCircleIcon className="w-10 h-10" />}
                       </div>
                       <div className="flex-1">
                          <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">{item.category}</p>
                          <h4 className="font-black text-lg text-white mb-2 leading-tight">{item.name}</h4>
                          <div className="flex items-center text-blue-400 text-[10px] font-black mb-4 uppercase">
                             <ArrowTrendingUpIcon className="w-3 h-3 mr-1" /> Quality Bonus: +{item.qualityBonus}
                          </div>
                          <div className="flex justify-between items-center">
                             <span className="font-black text-emerald-400 tracking-tighter">{item.price.toLocaleString()} DECON</span>
                             <button 
                               disabled={owned || gameState.stats.decon < item.price} 
                               onClick={() => onBuyItem(item)} 
                               className={`px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase transition-all shadow-xl active:scale-95 ${owned ? 'bg-slate-800 text-slate-600' : 'bg-blue-600 hover:bg-blue-500 text-white'}`}
                             >
                               {owned ? 'OWNED' : 'BUY'}
                             </button>
                          </div>
                       </div>
                    </div>
                  );
                })}
             </div>
          </div>
        );

      case 'Streaming Studio':
        if (gameState.isStreaming) {
          return (
            <div className="h-full flex flex-col bg-black">
              <div className="flex-1 relative flex items-center justify-center overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-indigo-950 via-slate-950 to-purple-950 opacity-40"></div>
                 
                 <div className="absolute top-6 left-6 flex space-x-6 bg-black/60 p-4 rounded-2xl backdrop-blur-xl border border-white/10 z-20 shadow-2xl">
                    <span className="text-[10px] text-red-500 font-black animate-pulse flex items-center uppercase tracking-widest">
                       <div className="w-2.5 h-2.5 bg-red-600 rounded-full mr-2 shadow-[0_0_12px_rgba(220,38,38,0.8)]"></div> LIVE
                    </span>
                    <span className="text-[10px] text-white font-black uppercase tracking-widest">{gameState.streamData?.viewers.toLocaleString()} VIEWS</span>
                    <span className="text-[10px] text-emerald-400 font-black uppercase tracking-widest">+ {gameState.streamData?.totalDonation.toLocaleString()} DECON</span>
                    <span className="text-[10px] text-slate-400 font-bold font-mono">{(gameState.streamData?.duration || 0) < 60 ? `00:${gameState.streamData?.duration.toString().padStart(2, '0')}` : `${Math.floor((gameState.streamData?.duration || 0)/60)}:${((gameState.streamData?.duration || 0)%60).toString().padStart(2, '0')}`}</span>
                 </div>

                 <div className="text-center z-10 animate-in zoom-in duration-700">
                    <div className="w-32 h-32 bg-red-600 rounded-full mx-auto mb-8 flex items-center justify-center animate-pulse shadow-[0_0_50px_rgba(220,38,38,0.4)] border-4 border-red-500/20">
                      <VideoCameraIcon className="w-16 h-16 text-white" />
                    </div>
                    <p className="text-white text-2xl font-black uppercase tracking-tighter shadow-sm">{gameState.streamData?.gameId}</p>
                    <p className="text-[10px] text-slate-400 mt-3 uppercase font-black tracking-[0.4em] opacity-60">Real-time Bitrate: 6.5 Mbps</p>
                 </div>

                 <div className="absolute right-0 bottom-0 top-0 w-80 bg-slate-900/60 backdrop-blur-2xl p-6 overflow-y-auto border-l border-white/5 z-20 shadow-2xl">
                    <h5 className="text-[10px] text-blue-400 uppercase font-black mb-8 tracking-[0.3em] border-b border-blue-500/20 pb-3">Live Stream Chat</h5>
                    <div className="space-y-5">
                       {gameState.streamData?.chat.map(chat => (
                         <div key={chat.id} className={`text-[12px] animate-in slide-in-from-right-4 duration-300 ${chat.type === 'donation' ? 'bg-emerald-600/20 p-4 rounded-2xl border border-emerald-500/30 shadow-lg' : ''}`}>
                            <p className={`font-black uppercase tracking-tight mb-0.5 ${chat.type === 'donation' ? 'text-emerald-400' : 'text-blue-400'}`}>{chat.user}</p>
                            <p className="text-white/90 leading-snug">{chat.text}</p>
                         </div>
                       ))}
                       {gameState.streamData?.chat.length === 0 && <p className="text-slate-600 text-[10px] font-bold text-center mt-10">Mencari penonton...</p>}
                    </div>
                 </div>
              </div>
              <div className="p-6 bg-slate-900 border-t border-slate-800 flex justify-between items-center z-30">
                 <div className="flex space-x-6 items-center">
                    <div>
                       <span className="text-[8px] text-slate-500 uppercase font-black block mb-1">Stream Status</span>
                       <span className="text-xs font-black text-emerald-500 uppercase">Excellent</span>
                    </div>
                    <div className="w-[1px] h-8 bg-slate-800"></div>
                    <div>
                       <span className="text-[8px] text-slate-500 uppercase font-black block mb-1">Subscribers gained</span>
                       <span className="text-xs font-black text-white">+{Math.floor((gameState.streamData?.viewers || 0) * 0.1)}</span>
                    </div>
                 </div>
                 <button onClick={onStopStream} className="bg-red-600 hover:bg-red-500 text-white px-10 py-4 rounded-[1.5rem] text-[10px] font-black uppercase shadow-2xl shadow-red-900/40 transition-all active:scale-95">AKHIRI SIARAN</button>
              </div>
            </div>
          );
        }
        return (
          <div className="p-16 flex flex-col items-center justify-center h-full text-center bg-slate-900 overflow-y-auto">
            <h2 className="text-5xl font-black text-white mb-4 tracking-tighter uppercase italic">Stream Studio Pro</h2>
            <p className="text-slate-500 text-sm mb-12 max-w-lg leading-relaxed font-medium">Hubungkan peralatan Anda, pilih konten terbaik, dan mulai raih popularitas sebagai kreator nomor satu.</p>
            
            <div className="w-full max-w-xl space-y-8 bg-slate-800/40 p-12 rounded-[3.5rem] border border-slate-700 shadow-2xl">
               <div className="grid grid-cols-2 gap-8 text-left">
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Select Content</label>
                     <select 
                        value={streamConfig.gameId}
                        onChange={(e) => setStreamConfig(prev => ({...prev, gameId: e.target.value}))}
                        className="w-full bg-slate-900 border-2 border-slate-700 rounded-2xl p-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-all font-bold appearance-none cursor-pointer"
                     >
                        {gameState.ownedGames.map(gid => {
                           const g = GAME_STORE_ITEMS.find(it => it.id === gid);
                           return <option key={gid} value={gid}>{g?.name?.toUpperCase()}</option>
                        })}
                     </select>
                  </div>
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Live Output</label>
                     <div className="grid grid-cols-2 gap-2">
                        {['1080p', '4K'].map(res => (
                           <button 
                              key={res}
                              onClick={() => setStreamConfig(prev => ({...prev, resolution: res}))}
                              className={`py-3 rounded-xl text-[10px] font-black border transition-all ${streamConfig.resolution === res ? 'bg-blue-600 border-blue-500 text-white shadow-lg' : 'bg-slate-900 border-slate-700 text-slate-500 hover:border-slate-500'}`}
                           >
                              {res}
                           </button>
                        ))}
                     </div>
                  </div>
               </div>
               <button 
                  onClick={() => {
                     if (gameState.stats.energy < 30) {
                        alert("Energi Anda terlalu rendah untuk mulai streaming!");
                        return;
                     }
                     onStartStream(streamConfig);
                  }} 
                  className="w-full bg-blue-600 hover:bg-blue-500 py-6 rounded-3xl font-black text-white shadow-2xl shadow-blue-900/30 transform transition-all hover:scale-[1.02] active:scale-95 uppercase tracking-widest text-sm"
               >
                  GO LIVE SEKARANG
               </button>
               <p className="text-[9px] text-slate-600 uppercase font-black tracking-[0.2em]">Estimasi kebutuhan energi: 30% per jam</p>
            </div>
          </div>
        );

      default:
        return <div className="p-20 text-center text-slate-500 font-black uppercase tracking-[0.4em] text-xs opacity-40">Application Logic Placeholder</div>;
    }
  };

  const windowZIndex = activeTab === 'none' ? zIndex : zIndex; // Placeholder logic
  const windowStyles = maximized ? {
    inset: 0,
    width: '100%',
    height: 'calc(100% - 48px)',
    zIndex
  } : {
    width: 'calc(100% - 150px)',
    height: 'calc(100% - 150px)',
    left: position.x,
    top: position.y,
    zIndex
  };

  return (
    <div 
      onClick={onFocus}
      className={`absolute bg-slate-900 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.6)] border border-white/10 overflow-hidden flex flex-col animate-in fade-in zoom-in duration-300 ${maximized ? '' : 'rounded-[3rem]'}`}
      style={windowStyles}
    >
      <div onMouseDown={handleMouseDown} className="h-14 bg-slate-950/80 backdrop-blur-md border-b border-white/5 flex items-center justify-between px-8 shrink-0 cursor-move">
        <div className="flex items-center space-x-3">
           <div className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">{appName}</span>
        </div>
        <div className="flex items-center space-x-4">
           <button onClick={(e) => { e.stopPropagation(); onMinimize(); }} className="p-2 hover:bg-white/5 rounded-xl transition-all group"><MinusIcon className="w-4 h-4 text-slate-600 group-hover:text-white" /></button>
           <button onClick={(e) => { e.stopPropagation(); onToggleMaximize(); }} className="p-2 hover:bg-white/5 rounded-xl transition-all group"><Square2StackIcon className="w-4 h-4 text-slate-600 group-hover:text-white" /></button>
           <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="p-2 hover:bg-red-500/80 rounded-xl transition-all group shadow-inner"><XMarkIcon className="w-4 h-4 text-slate-600 group-hover:text-white" /></button>
        </div>
      </div>
      <div className="flex-1 overflow-hidden relative shadow-inner">{renderAppContent()}</div>
    </div>
  );
};

export default PCAppContainer;
