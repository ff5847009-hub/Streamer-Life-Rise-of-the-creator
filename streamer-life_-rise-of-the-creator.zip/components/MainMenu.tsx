
import React from 'react';

interface MainMenuProps {
  onPlay: () => void;
  onCredits: () => void;
  onReset: () => void;
  onExit: () => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onPlay, onCredits, onReset, onExit }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-slate-900 to-indigo-950 p-8">
      <div className="mb-12 text-center animate-pulse">
        <h1 className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-2 drop-shadow-lg tracking-tighter uppercase">
          Streamer Life
        </h1>
        <p className="text-blue-300 font-medium tracking-[0.2em] text-sm uppercase">Rise of the Creator</p>
      </div>

      <div className="flex flex-col space-y-4 w-full max-w-xs">
        <button 
          onClick={onPlay}
          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-5 px-6 rounded-2xl transition-all transform hover:scale-105 active:scale-95 shadow-2xl shadow-blue-900/40 border-b-4 border-blue-800"
        >
          START CAREER
        </button>
        <button 
          onClick={onCredits}
          className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-4 px-6 rounded-2xl transition-all shadow-lg border-b-4 border-slate-900"
        >
          CREDITS
        </button>
        <button 
          onClick={onReset}
          className="w-full bg-red-900/30 hover:bg-red-900/50 text-red-300 font-bold py-3 px-6 rounded-2xl transition-all border-b-2 border-red-950/50 text-xs"
        >
          RESET DATA
        </button>
      </div>
      
      <div className="mt-auto text-slate-500 text-[10px] font-black tracking-widest uppercase">
        v1.2.0 • OneComplier Production
      </div>
    </div>
  );
};

export default MainMenu;
